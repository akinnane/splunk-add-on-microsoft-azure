Splunk Add-on for Microsoft Azure

Copyright (C) 2005-2022 Splunk Inc. All rights reserved.
# Binary File Declaration
